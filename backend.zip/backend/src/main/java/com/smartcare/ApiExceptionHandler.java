package com.smartcare;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import java.util.Map;
@RestControllerAdvice
public class ApiExceptionHandler {
 @ExceptionHandler(IllegalArgumentException.class)
 public ResponseEntity<Map<String,String>> bad(IllegalArgumentException e){return ResponseEntity.badRequest().body(Map.of("message",e.getMessage()==null?"Bad request":e.getMessage()));}
 @ExceptionHandler(Exception.class)
 public ResponseEntity<Map<String,String>> any(Exception e){return ResponseEntity.status(500).body(Map.of("message","Server error","detail",e.getMessage()==null?"":e.getMessage()));}
}