package com.smartcare;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Service
public class JwtService {
 private final SecretKey key;
 public JwtService(@Value("${smartcare.jwt.secret}") String secret){
  key=Keys.hmacShaKeyFor(secret.getBytes(StandardCharsets.UTF_8));
 }
 public String create(long id,String role){
  return Jwts.builder().subject(String.valueOf(id)).claim("role",role).issuedAt(new Date()).expiration(new Date(System.currentTimeMillis()+7*24*3600_000L)).signWith(key).compact();
 }
 public Claims claims(String token){return Jwts.parser().verifyWith(key).build().parseSignedClaims(token).getPayload();}
}