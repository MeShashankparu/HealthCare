package com.smartcare;

import java.util.*;
import java.util.regex.*;

/**
 * Best-effort heuristic parser that turns free-form prescription text (typed, pasted,
 * or extracted via OCR/PDF text-layer on the client) into structured medicine entries.
 *
 * This is not a medical NLP model — it recognises common prescription shorthand
 * (dosage units, frequency phrases like "twice daily"/"BID"/"1-0-1", and duration
 * phrases like "for 5 days"). Every result is shown to the patient for review/edit
 * before anything is scheduled, so recall matters more than perfect precision.
 */
public class PrescriptionParser {

 private static final Pattern DOSAGE = Pattern.compile("(\\d+(?:\\.\\d+)?)\\s?(mg|mcg|g|ml|iu)\\b", Pattern.CASE_INSENSITIVE);
 private static final Pattern DURATION_DAYS = Pattern.compile("(?:for|x|×)?\\s*(\\d+)\\s*day", Pattern.CASE_INSENSITIVE);
 private static final Pattern DURATION_WEEKS = Pattern.compile("(?:for|x|×)?\\s*(\\d+)\\s*week", Pattern.CASE_INSENSITIVE);
 private static final Pattern EVERY_N_HOURS = Pattern.compile("every\\s+(\\d+)\\s*(?:hrs?|hours?)", Pattern.CASE_INSENSITIVE);
 private static final Pattern DOSE_CODE = Pattern.compile("\\b([01])-([01])-([01])(?:-([01]))?\\b");
 private static final Pattern LEADING_PREFIX = Pattern.compile("^(tab\\.?|tabs?\\.?|tablet|cap\\.?|capsule|syp\\.?|syrup|inj\\.?|injection|oint\\.?|ointment|drops?)\\s+", Pattern.CASE_INSENSITIVE);
 private static final Pattern BULLET = Pattern.compile("^[\\-*•\\d]+[).:]?\\s*");

 private static final List<String> HEADER_NOISE = List.of("dr.", "doctor", "patient name", "patient:", "age:", "date:", "hospital", "clinic", "address", "phone", "signature", "diagnosis", "reg no", "prescription", "rx no");

 public static List<Map<String,Object>> parse(String rawText){
  List<Map<String,Object>> out = new ArrayList<>();
  if (rawText == null || rawText.isBlank()) return out;

  // Split on newlines and on ';' — clinicians often list multiple drugs per line separated by ';'
  String[] rawLines = rawText.replace("\r", "\n").split("\n");
  List<String> lines = new ArrayList<>();
  for (String l : rawLines) for (String part : l.split(";")) if (!part.isBlank()) lines.add(part.trim());

  long seq = 0;
  for (String line : lines) {
   String lower = line.toLowerCase();
   if (lower.isBlank() || lower.length() < 3) continue;
   if (HEADER_NOISE.stream().anyMatch(lower::contains) && !DOSAGE.matcher(line).find()) continue; // looks like header/footer, not a drug line

   boolean hasDosage = DOSAGE.matcher(line).find();
   boolean hasFrequencyHint = lower.matches(".*(daily|day\\b|times a day|/day|bid|tid|qid|od\\b|hs\\b|stat\\b).*") || DOSE_CODE.matcher(line).find() || EVERY_N_HOURS.matcher(line).find();
   boolean hasKnownPrefix = LEADING_PREFIX.matcher(line.trim()).find();
   if (!hasDosage && !hasFrequencyHint && !hasKnownPrefix) continue; // not confidently a medicine line

   seq++;
   Map<String,Object> med = new LinkedHashMap<>();
   med.put("id", "parsed-" + seq);
   med.put("name", extractName(line));
   med.put("dosage", extractDosage(line));
   Object[] freq = extractFrequency(line);
   med.put("frequency_label", freq[0]);
   med.put("times", freq[1]);
   med.put("duration_days", extractDurationDays(line));
   out.add(med);
  }
  return out;
 }

 private static String extractName(String line){
  String s = BULLET.matcher(line.trim()).replaceFirst("");
  s = LEADING_PREFIX.matcher(s).replaceFirst("");
  // Name is whatever comes before the dosage number, frequency code, or a trailing dash/comma section
  Matcher d = DOSAGE.matcher(s);
  int cut = d.find() ? d.start() : s.length();
  Matcher code = DOSE_CODE.matcher(s);
  if (code.find() && code.start() < cut) cut = code.start();
  String name = s.substring(0, cut).trim();
  name = name.replaceAll("[-–,:]+$", "").trim();
  if (name.isBlank()) name = s.trim(); // fall back to the full line rather than losing the entry
  // Title-case a plain lowercase capture for readability
  if (!name.isEmpty() && name.equals(name.toLowerCase())) {
   name = Character.toUpperCase(name.charAt(0)) + name.substring(1);
  }
  return name;
 }

 private static String extractDosage(String line){
  Matcher m = DOSAGE.matcher(line);
  return m.find() ? (m.group(1) + m.group(2).toLowerCase()) : "";
 }

 /** Returns {String frequencyLabel, List<String> times} */
 private static Object[] extractFrequency(String line){
  String lower = line.toLowerCase();
  Matcher code = DOSE_CODE.matcher(line);
  if (code.find()) {
   List<String> slots = new ArrayList<>();
   String[] base = {"08:00","14:00","20:00","23:00"};
   int on = 0;
   for (int i = 1; i <= 4; i++) {
    String g = code.group(i);
    if (g != null && g.equals("1")) { slots.add(base[i-1]); on++; }
   }
   if (on > 0) return new Object[]{ on + "x daily (" + line.substring(code.start(), code.end()) + ")", slots };
  }
  Matcher everyN = EVERY_N_HOURS.matcher(line);
  if (everyN.find()) {
   int hrs = Integer.parseInt(everyN.group(1));
   List<String> slots = new ArrayList<>();
   int startHour = 8, count = Math.max(1, Math.min(6, 24 / Math.max(hrs,1)));
   for (int i = 0; i < count; i++) slots.add(String.format("%02d:00", (startHour + i*hrs) % 24));
   return new Object[]{ "Every " + hrs + " hours", slots };
  }
  if (lower.contains("four times") || lower.contains("qid")) return new Object[]{"Four times daily", List.of("08:00","12:00","16:00","20:00")};
  if (lower.contains("thrice") || lower.contains("three times") || lower.contains("tid")) return new Object[]{"Three times daily", List.of("08:00","14:00","20:00")};
  if (lower.contains("twice") || lower.contains("two times") || lower.contains("bid")) return new Object[]{"Twice daily", List.of("08:00","20:00")};
  if (lower.contains("once") || lower.matches(".*\\bod\\b.*") || lower.contains("once daily") || lower.contains("once a day")) return new Object[]{"Once daily", List.of("08:00")};
  if (lower.matches(".*\\bhs\\b.*") || lower.contains("bedtime") || lower.contains("at night")) return new Object[]{"At bedtime", List.of("22:00")};
  // Default when no frequency phrase is recognised — safe, editable default
  return new Object[]{"Once daily", List.of("08:00")};
 }

 private static int extractDurationDays(String line){
  Matcher w = DURATION_WEEKS.matcher(line);
  if (w.find()) { try { return Integer.parseInt(w.group(1)) * 7; } catch(Exception ignored){} }
  Matcher d = DURATION_DAYS.matcher(line);
  if (d.find()) { try { return Integer.parseInt(d.group(1)); } catch(Exception ignored){} }
  return 5; // sensible editable default, matches the manual-add default in the UI
 }
}
