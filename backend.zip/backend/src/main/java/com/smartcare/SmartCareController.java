package com.smartcare;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import java.nio.file.*;
import java.time.*;
import java.util.*;

@RestController
@CrossOrigin(origins="*", allowedHeaders="*")
public class SmartCareController {
 private final Store db; private final JwtService jwt; private final BCryptPasswordEncoder encoder=new BCryptPasswordEncoder();
 private final Path uploads;
 public SmartCareController(Store db,JwtService jwt,@Value("${smartcare.upload-dir:./data/uploads}") String uploadDir){this.db=db;this.jwt=jwt;uploads=Paths.get(uploadDir);}

 // Email: standard name@domain.tld shape. Password (registration only): 8+ chars, at least one uppercase, one lowercase, one digit.
 private static final java.util.regex.Pattern EMAIL_RE=java.util.regex.Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
 private static final java.util.regex.Pattern PASSWORD_RE=java.util.regex.Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$");
 private void validateEmail(String email){if(email==null||!EMAIL_RE.matcher(email).matches())throw new IllegalArgumentException("Enter a valid email address (e.g. name@example.com)");}
 private void validatePassword(String password){if(password==null||!PASSWORD_RE.matcher(password).matches())throw new IllegalArgumentException("Password must be at least 8 characters and include an uppercase letter, a lowercase letter, and a number");}

 private Map<String,Object> publicUser(Map<String,Object> u){
  if(u==null)return null;
  Map<String,Object>x=new HashMap<>(u);
  x.remove("password_hash");
  // Normalize legacy hospitalId records and expose hospital details directly with the doctor.
  Object legacy=x.get("hospitalId");
  Object assigned=x.get("hospital_id");
  if((assigned==null || String.valueOf(assigned).isBlank()) && legacy!=null && !String.valueOf(legacy).isBlank())
   x.put("hospital_id",db.toLong(legacy));
  x.remove("hospitalId");
  Object hospitalId=x.get("hospital_id");
  if(hospitalId!=null && !String.valueOf(hospitalId).isBlank()){
   Map<String,Object> h=db.find("hospitals",hospitalId);
   if(h!=null){
    x.put("hospital_name",h.getOrDefault("name",""));
    x.put("hospital_address",h.getOrDefault("address",""));
    x.put("hospital_city",h.getOrDefault("city",""));
   }
  }
  return x;
 }
 private Map<String,Object> normalizeHospitalAssignment(Map<String,Object> input){
  Map<String,Object>x=new HashMap<>(input);
  if(x.containsKey("hospitalId")){
   Object v=x.get("hospitalId");
   x.put("hospital_id",v==null||String.valueOf(v).isBlank()?null:db.toLong(v));
   x.remove("hospitalId");
  }
  return x;
 }
 private Map<String,Object> saveDoctorHospital(Map<String,Object> source, Map<String,Object> doctor){
  String name=String.valueOf(source.getOrDefault("hospitalName","")).trim();
  String address=String.valueOf(source.getOrDefault("hospitalAddress","")).trim();
  doctor.remove("hospitalName");
  doctor.remove("hospitalAddress");
  Object hospitalId=doctor.get("hospital_id");
  if(name.isBlank() && address.isBlank()) return doctor;
  if(name.isBlank()) throw new IllegalArgumentException("Hospital name is required when adding an address");
  Map<String,Object> h=hospitalId==null?null:db.find("hospitals",hospitalId);
  if(h==null){
   Map<String,Object> created=new HashMap<>();
   created.put("name",name); created.put("address",address); created.put("city",source.getOrDefault("hospitalCity",""));
   created.put("created_by",doctor.get("id"));
   h=db.insert("hospitals",created);
   doctor.put("hospital_id",h.get("id"));
  }else{
   Map<String,Object> update=new HashMap<>(); update.put("name",name); update.put("address",address);
   if(source.containsKey("hospitalCity")) update.put("city",source.get("hospitalCity"));
   db.update("hospitals",db.toLong(h.get("id")),update);
  }
  return doctor;
 }
 private Long userId(String auth,String role){
  try{if(auth==null||!auth.startsWith("Bearer "))return null;var c=jwt.claims(auth.substring(7));if(!role.equals(c.get("role",String.class)))return null;return Long.valueOf(c.getSubject());}catch(Exception e){return null;}
 }
 private ResponseEntity<?> need(String auth,String role){return ResponseEntity.status(401).body(Map.of("message","Authentication required"));}

 @GetMapping("/") public Map<String,Object> home(){return Map.of("ok",true,"service","SmartCare API","message","Spring Boot backend is running");}
 @GetMapping("/api/health") public Map<String,Object> health(){return Map.of("ok",true,"service","SmartCare API","database","JSON file managed by Spring Boot");}

 // ---------- Auth ----------
 @PostMapping("/api/auth/register/request-otp") public Map<String,Object> patientOtp(@RequestBody Map<String,Object> b){
  String email=String.valueOf(b.getOrDefault("email","")).trim().toLowerCase();
  if(String.valueOf(b.getOrDefault("name","")).isBlank()) throw new IllegalArgumentException("Name is required");
  validateEmail(email);
  validatePassword(String.valueOf(b.getOrDefault("password","")));
  if(db.findBy("patients","email",email)!=null) throw new IllegalArgumentException("Email already registered");
  String otp=String.format("%06d",new Random().nextInt(1_000_000));
  Map<String,Object> p=new HashMap<>(b);p.put("email",email);p.put("password_hash",encoder.encode(String.valueOf(b.get("password"))));p.remove("password");
  db.insert("otps",Map.of("email",email,"type","patient_register","code",otp,"payload",p,"expires_at",Instant.now().plusSeconds(600).toString()));
  return Map.of("message","Verification code generated. Use the development code below.","devOtp",otp);
 }
 @PostMapping("/api/auth/register/verify-otp") public ResponseEntity<?> patientVerify(@RequestBody Map<String,Object> b){
  Map<String,Object> o=db.all("otps").stream().filter(x->String.valueOf(x.get("email")).equalsIgnoreCase(String.valueOf(b.get("email")))&&String.valueOf(x.get("type")).equals("patient_register")&&String.valueOf(x.get("code")).equals(String.valueOf(b.get("code")))).findFirst().orElse(null);
  if(o==null)return ResponseEntity.badRequest().body(Map.of("message","Invalid verification code"));
  Map<String,Object> p=new HashMap<>((Map<String,Object>)o.get("payload"));
  Map<String,Object> newPatient=new HashMap<>();
  newPatient.put("name",p.getOrDefault("name",""));
  newPatient.put("email",p.get("email"));
  newPatient.put("password_hash",p.get("password_hash"));
  newPatient.put("phone","");
  newPatient.put("city","");
  newPatient.put("latitude",null);
  newPatient.put("longitude",null);
  newPatient.put("chronic_conditions","");
  Map<String,Object> u=db.insert("patients",newPatient);
  db.insert("rewards",Map.of("patient_id",u.get("id"),"points",0,"level","Starter","streak_current",0,"streak_best",0));
  return ResponseEntity.ok(Map.of("user",publicUser(u),"token",jwt.create(db.toLong(u.get("id")),"patient")));
 }
 @PostMapping("/api/auth/login") public ResponseEntity<?> patientLogin(@RequestBody Map<String,Object> b){
  String loginEmail=String.valueOf(b.getOrDefault("email","")).trim().toLowerCase();
  validateEmail(loginEmail);
  Map<String,Object> u=db.findBy("patients","email",loginEmail);
  if(u==null||!encoder.matches(String.valueOf(b.getOrDefault("password","")),String.valueOf(u.get("password_hash"))))return ResponseEntity.status(401).body(Map.of("message","Invalid credentials"));
  return ResponseEntity.ok(Map.of("user",publicUser(u),"token",jwt.create(db.toLong(u.get("id")),"patient")));
 }
 @GetMapping("/api/me") public ResponseEntity<?> me(@RequestHeader(value="Authorization",required=false)String a){Long id=userId(a,"patient");if(id==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(publicUser(db.find("patients",id)));}
 @PutMapping("/api/me") public ResponseEntity<?> updateMe(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){Long id=userId(a,"patient");if(id==null)return ResponseEntity.status(401).build();Map<String,Object> c=new HashMap<>();for(String k:List.of("name","phone","city","latitude","longitude","chronic_conditions"))if(b.containsKey(k))c.put(k,b.get(k));return ResponseEntity.ok(publicUser(db.update("patients",id,c)));}

 // ---------- Common data ----------
 @GetMapping("/api/hospitals") public List<Map<String,Object>> hospitals(@RequestParam(defaultValue="")String q){return db.all("hospitals").stream().filter(h->q.isBlank()||String.valueOf(h.getOrDefault("name","")).toLowerCase().contains(q.toLowerCase())||String.valueOf(h.getOrDefault("city","")).toLowerCase().contains(q.toLowerCase())).toList();}
 @GetMapping("/api/hospitals/{id}") public ResponseEntity<?> hospital(@PathVariable long id){Map<String,Object> h=db.find("hospitals",id);if(h==null)return ResponseEntity.notFound().build();Map<String,Object>x=new HashMap<>(h);x.put("doctors",db.all("doctors").stream().map(this::publicUser).filter(d->Objects.equals(db.toLong(d.get("hospital_id")),id)).toList());return ResponseEntity.ok(x);}
 @GetMapping("/api/doctors") public List<Map<String,Object>> doctors(@RequestParam(defaultValue="")String q){return db.all("doctors").stream().filter(d->q.isBlank()||(String.valueOf(d.getOrDefault("name",""))+" "+String.valueOf(d.getOrDefault("specialty",""))).toLowerCase().contains(q.toLowerCase())).map(d->{Map<String,Object>x=publicUser(d);Map<String,Object>h=db.find("hospitals",x.get("hospital_id"));x.put("hospital_name",h==null?"":h.get("name"));x.put("address",h==null?"":h.get("address"));x.put("city",h==null?"":h.get("city"));return x;}).toList();}

 @PostMapping("/api/appointments") public ResponseEntity<?> createAppt(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();Map<String,Object> x=new HashMap<>();x.put("patient_id",pid);x.put("doctor_id",db.toLong(b.get("doctorId")));x.put("hospital_id",db.toLong(b.get("hospitalId")));x.put("appointment_date",b.getOrDefault("appointmentDate",""));x.put("token",db.filter("appointments","hospital_id",b.get("hospitalId")).size()+1);x.put("status","Pending");x.put("patient_name",b.getOrDefault("patientName",""));x.put("patient_number",b.getOrDefault("patientNumber",""));x.put("patient_age",b.getOrDefault("patientAge",null));x.put("condition","Emergency".equals(b.get("condition"))?"Emergency":"General");x.put("disease",b.getOrDefault("disease",""));Map<String,Object> ap=db.insert("appointments",x);Map<String,Object>r=db.findBy("rewards","patient_id",pid);if(r!=null)db.update("rewards",r.get("id"),Map.of("points",db.toLong(r.get("points"))+100));return ResponseEntity.status(201).body(appointmentView(ap));}
 @GetMapping("/api/appointments") public ResponseEntity<?> appointments(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("appointments","patient_id",pid).stream().map(this::appointmentView).toList());}
 @PutMapping("/api/appointments/{id}/cancel")
 public ResponseEntity<?> cancelPatientAppointment(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){
  Long pid=userId(a,"patient");
  if(pid==null)return ResponseEntity.status(401).build();
  Map<String,Object> ap=db.find("appointments",id);
  if(ap==null)return ResponseEntity.notFound().build();
  if(!Objects.equals(String.valueOf(ap.get("patient_id")),String.valueOf(pid)))
   return ResponseEntity.status(403).body(Map.of("message","You can only cancel your own appointments"));
  String status=String.valueOf(ap.getOrDefault("status","Pending"));
  if("Completed".equals(status)||"Cancelled".equals(status))
   return ResponseEntity.badRequest().body(Map.of("message","This appointment cannot be cancelled"));
  Map<String,Object>x=db.update("appointments",id,Map.of("status","Cancelled","cancelled_at",Instant.now().toString(),"cancelled_by","patient"));
  return x==null?ResponseEntity.notFound().build():ResponseEntity.ok(appointmentView(x));
 }

 @GetMapping("/api/rewards") public ResponseEntity<?> rewards(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(Optional.ofNullable(db.findBy("rewards","patient_id",pid)).orElse(Map.of("patient_id",pid,"points",0,"level","Starter")));}

 private Map<String,Object> appointmentView(Map<String,Object>a){Map<String,Object>x=new HashMap<>(a);Map<String,Object>d=db.find("doctors",a.get("doctor_id")),h=db.find("hospitals",a.get("hospital_id"));x.put("doctor_name",d==null?"":d.get("name"));x.put("specialty",d==null?"":d.get("specialty"));x.put("hospital_name",h==null?"":h.get("name"));return x;}

 @PostMapping("/api/dev/seed") public Map<String,Object> seed(){if(db.count("hospitals")==0){Map<String,Object>h=db.insert("hospitals",Map.of("name","Sample Hospital","address","Sample Address","city","Hyderabad","phone","0000000000","latitude",17.385,"longitude",78.4867,"departments",List.of("General Medicine","Cardiology")));db.insert("doctors",Map.of("hospital_id",h.get("id"),"name","Sample Doctor","specialty","General Medicine","phone","","experience","5 years","fee","Consultation fee"));}return Map.of("message","Seed data created");}

 // ---------- Patient features ----------
 @PostMapping("/api/patient/prescriptions") public ResponseEntity<?> uploadPrescription(@RequestHeader(value="Authorization",required=false)String a,@RequestParam(value="file",required=false)MultipartFile file,@RequestParam(value="text",required=false)String text){
  Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();
  if((file==null||file.isEmpty())&&(text==null||text.isBlank())) throw new IllegalArgumentException("Upload a file or paste the prescription text");
  try{
   String fileName=null, filePath=null;
   if(file!=null&&!file.isEmpty()){
    Files.createDirectories(uploads);
    String name=System.currentTimeMillis()+"-"+Objects.requireNonNull(file.getOriginalFilename()).replaceAll("[^a-zA-Z0-9._-]","_");
    Path p=uploads.resolve(name);
    Files.copy(file.getInputStream(),p,StandardCopyOption.REPLACE_EXISTING);
    fileName=file.getOriginalFilename(); filePath=p.toString();
   }
   List<Map<String,Object>> medicines = new ArrayList<>(PrescriptionParser.parse(text));
   Map<String,Object> rec=new LinkedHashMap<>();
   rec.put("patient_id",pid);
   rec.put("file_name",fileName);
   rec.put("file_path",filePath);
   rec.put("source_text",text==null?"":text);
   rec.put("status","Uploaded");
   rec.put("medicines",medicines);
   return ResponseEntity.status(201).body(db.insert("prescriptions",rec));
  }catch(Exception e){return ResponseEntity.internalServerError().body(Map.of("message","Upload failed"));}
 }
 @GetMapping("/api/patient/prescriptions") public ResponseEntity<?> prescriptions(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("prescriptions","patient_id",pid));}
 @GetMapping("/api/patient/prescriptions/{id}") public ResponseEntity<?> prescription(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){Long pid=userId(a,"patient");Map<String,Object>x=db.find("prescriptions",id);if(pid==null||x==null||!String.valueOf(x.get("patient_id")).equals(String.valueOf(pid)))return ResponseEntity.notFound().build();return ResponseEntity.ok(x);}
 @PutMapping("/api/patient/prescriptions/{id}/medicines") public ResponseEntity<?> medicines(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id,@RequestBody Map<String,Object>b){
  Long pid=userId(a,"patient");Map<String,Object>x=db.find("prescriptions",id);
  if(pid==null||x==null||!String.valueOf(x.get("patient_id")).equals(String.valueOf(pid)))return ResponseEntity.notFound().build();
  return ResponseEntity.ok(db.update("prescriptions",id,Map.of("medicines",b.getOrDefault("medicines",List.of()))));
 }
 @PostMapping("/api/patient/prescriptions/{id}/activate") public ResponseEntity<?> activate(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){
  Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();
  Map<String,Object> presc=db.find("prescriptions",id);
  if(presc==null||!String.valueOf(presc.get("patient_id")).equals(String.valueOf(pid)))return ResponseEntity.notFound().build();
  @SuppressWarnings("unchecked") List<Map<String,Object>> meds=(List<Map<String,Object>>) presc.getOrDefault("medicines", List.of());
  for(Map<String,Object> m: meds){
   createMedicationWithDoses(pid, id,
    String.valueOf(m.getOrDefault("name","")),
    String.valueOf(m.getOrDefault("dosage","")),
    String.valueOf(m.getOrDefault("frequency_label","")),
    (List<?>) m.getOrDefault("times", List.of("08:00")),
    (int) db.toLong(m.getOrDefault("duration_days",5)));
  }
  return ResponseEntity.ok(db.update("prescriptions",id,Map.of("status","Active")));
 }

 /** Creates one medications row and generates its dose_logs for every day/time of the course. Shared by prescription activation and manual add. */
 private void createMedicationWithDoses(Long pid, Long prescriptionId, String name, String dosage, String frequencyLabel, List<?> times, int durationDays){
  LocalDate start=LocalDate.now();
  int days=Math.max(1,durationDays);
  LocalDate end=start.plusDays(days-1);
  Map<String,Object> medRec=new LinkedHashMap<>();
  medRec.put("patient_id",pid);
  if(prescriptionId!=null) medRec.put("prescription_id",prescriptionId);
  medRec.put("name",name);
  medRec.put("dosage",dosage);
  medRec.put("frequency_label",frequencyLabel);
  medRec.put("times",times);
  medRec.put("duration_days",days);
  medRec.put("start_date",start.toString());
  medRec.put("end_date",end.toString());
  medRec.put("active",true);
  Map<String,Object> saved=db.insert("medications",medRec);
  Object medId=saved.get("id");
  for(int day=0; day<days; day++){
   LocalDate date=start.plusDays(day);
   for(Object t: times){
    Map<String,Object> dose=new LinkedHashMap<>();
    dose.put("patient_id",pid);
    dose.put("medication_id",medId);
    dose.put("medicine_name",name);
    dose.put("dosage",dosage);
    dose.put("scheduled_date",date.toString());
    dose.put("scheduled_time",String.valueOf(t));
    dose.put("status","pending");
    db.insert("dose_logs",dose);
   }
  }
 }

 @GetMapping("/api/patient/medications") public ResponseEntity<?> meds(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("medications","patient_id",pid));}
 @PostMapping("/api/patient/medications") public ResponseEntity<?> addMed(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){
  Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();
  String name=String.valueOf(b.getOrDefault("name","")).trim();
  if(name.isBlank()) throw new IllegalArgumentException("Medicine name is required");
  @SuppressWarnings("unchecked") List<Object> times=(List<Object>) b.getOrDefault("times", List.of("08:00"));
  if(times.isEmpty()) times=List.of("08:00");
  int duration=(int) db.toLong(b.getOrDefault("duration_days",5));
  createMedicationWithDoses(pid, null, name, String.valueOf(b.getOrDefault("dosage","")), String.valueOf(b.getOrDefault("frequency_label","")), times, duration);
  return ResponseEntity.status(201).body(db.filter("medications","patient_id",pid).stream().reduce((f,s)->s).orElse(null));
 }
 @DeleteMapping("/api/patient/medications/{id}") public ResponseEntity<?> delMed(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){
  Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();
  boolean removed=db.remove("medications",id);
  int cleared=db.removeWhere("dose_logs", d -> String.valueOf(d.get("medication_id")).equals(String.valueOf(id)) && "pending".equals(d.get("status")));
  return ResponseEntity.ok(Map.of("deleted",removed,"reminders_cleared",cleared));
 }
 @GetMapping("/api/patient/doses/today") public ResponseEntity<?> dosesToday(@RequestHeader(value="Authorization",required=false)String a){
  Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();
  String today=LocalDate.now().toString();
  return ResponseEntity.ok(db.filterWhere("dose_logs", d -> String.valueOf(d.get("patient_id")).equals(String.valueOf(pid)) && today.equals(d.get("scheduled_date"))));
 }
 @GetMapping("/api/patient/doses") public ResponseEntity<?> doses(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("dose_logs","patient_id",pid));}
 @PutMapping("/api/patient/doses/{id}/take") public ResponseEntity<?> take(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.update("dose_logs",id,Map.of("status","taken","taken_at",Instant.now().toString())));}
 @PutMapping("/api/patient/doses/{id}/skip") public ResponseEntity<?> skip(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.update("dose_logs",id,Map.of("status","missed")));}

 @GetMapping("/api/patient/rewards/summary") public ResponseEntity<?> rewardSummary(@RequestHeader(value="Authorization",required=false)String a){return rewards(a);}
 @GetMapping("/api/rewards/catalog") public List<Map<String,Object>> catalog(){
  return List.of(
   Map.of("points",300,"discount_percent",10,"label","10% off your next prescription"),
   Map.of("points",600,"discount_percent",20,"label","20% off your next prescription"),
   Map.of("points",1000,"discount_percent",35,"label","35% off your next prescription")
  );
 }
 @PostMapping("/api/patient/rewards/redeem") public ResponseEntity<?> redeem(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){
  Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();
  Map<String,Object>r=db.findBy("rewards","patient_id",pid);
  long cost=db.toLong(b.getOrDefault("points",0));
  Map<String,Object> tier=catalog().stream().filter(c->db.toLong(c.get("points"))==cost).findFirst().orElse(null);
  if(r==null||tier==null||db.toLong(r.get("points"))<cost)return ResponseEntity.badRequest().body(Map.of("message","Not enough points"));
  db.update("rewards",r.get("id"),Map.of("points",db.toLong(r.get("points"))-cost));
  String code="SC-"+String.format("%06d",new Random().nextInt(1_000_000));
  Map<String,Object> saved=db.insert("redemptions",Map.of("patient_id",pid,"points_used",cost,"discount_percent",tier.get("discount_percent"),"code",code,"redeemed_at",Instant.now().toString()));
  Map<String,Object> out=new HashMap<>(saved);out.put("code",code);out.put("discount_percent",tier.get("discount_percent"));
  return ResponseEntity.ok(out);
 }
 @GetMapping("/api/patient/rewards/redemptions") public ResponseEntity<?> redemptions(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("redemptions","patient_id",pid));}
 @GetMapping("/api/patient/food-recommendations") public Map<String,Object> food(){
  return Map.of("based_on","your health profile","recommendations",List.of(
   Map.of("condition","General wellness","recommend",List.of("Vegetables","Whole grains","Lean protein"),"avoid",List.of("Sugary drinks","Fried snacks")),
   Map.of("condition","Hydration","recommend",List.of("Water","Coconut water","Herbal tea"),"avoid",List.of("Excess caffeine","Alcohol"))
  ));
 }

 @PostMapping("/api/patient/reports") public ResponseEntity<?> report(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();Map<String,Object>x=new HashMap<>(b);x.put("patient_id",pid);return ResponseEntity.ok(db.insert("reports",x));}
 @GetMapping("/api/patient/reports") public ResponseEntity<?> reports(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("reports","patient_id",pid));}
 @GetMapping("/api/patient/health-trends") public ResponseEntity<?> trends(@RequestHeader(value="Authorization",required=false)String a){Long pid=userId(a,"patient");if(pid==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(buildHealthTrends(pid));}

 /** Groups raw health_metrics rows into {test_name, unit, points:[{date,value}]} series, as the trend charts expect. */
 private List<Map<String,Object>> buildHealthTrends(long patientId){
  Map<String,List<Map<String,Object>>> byTest = new LinkedHashMap<>();
  for(Map<String,Object> m: db.filter("health_metrics","patient_id",patientId)){
   String testName=String.valueOf(m.getOrDefault("test_name","Unknown"));
   byTest.computeIfAbsent(testName,k->new ArrayList<>()).add(m);
  }
  List<Map<String,Object>> out=new ArrayList<>();
  for(Map.Entry<String,List<Map<String,Object>>> e: byTest.entrySet()){
   List<Map<String,Object>> metrics=e.getValue();
   metrics.sort(Comparator.comparing(m->String.valueOf(m.getOrDefault("date",m.get("created_at")))));
   List<Map<String,Object>> points=new ArrayList<>();
   for(Map<String,Object> m: metrics) points.add(Map.of("date",String.valueOf(m.getOrDefault("date",m.get("created_at"))),"value",m.getOrDefault("value","")));
   Map<String,Object> trend=new LinkedHashMap<>();
   trend.put("test_name",e.getKey());
   trend.put("unit",metrics.get(metrics.size()-1).getOrDefault("unit",""));
   trend.put("points",points);
   out.add(trend);
  }
  return out;
 }

 /** Streaks/points come straight from the rewards record; adherence_rate is computed from completed dose history. */
 private Map<String,Object> buildAdherence(long patientId){
  Map<String,Object> r = db.findBy("rewards","patient_id",patientId);
  Map<String,Object> out=new LinkedHashMap<>();
  out.put("streak_current", r==null?0:db.toLong(r.get("streak_current")));
  out.put("streak_best", r==null?0:db.toLong(r.get("streak_best")));
  out.put("points", r==null?0:db.toLong(r.get("points")));
  out.put("level", r==null?"Starter":String.valueOf(r.get("level")));
  List<Map<String,Object>> doses = db.filter("dose_logs","patient_id",patientId);
  long taken = doses.stream().filter(d->"taken".equals(d.get("status"))).count();
  long missed = doses.stream().filter(d->"missed".equals(d.get("status"))).count();
  out.put("adherence_rate", (taken+missed)>0 ? Math.round(100.0*taken/(taken+missed)) : null);
  return out;
 }

 // ---------- Doctor auth ----------
 @PostMapping("/api/doctor/auth/register/request-otp") public Map<String,Object> doctorOtp(@RequestBody Map<String,Object>b){String email=String.valueOf(b.getOrDefault("email","")).trim().toLowerCase();validateEmail(email);validatePassword(String.valueOf(b.getOrDefault("password","")));if(db.findBy("doctors","email",email)!=null)throw new IllegalArgumentException("Email already registered");String otp=String.format("%06d",new Random().nextInt(1_000_000));Map<String,Object>p=new HashMap<>(b);p.put("email",email);p.put("password_hash",encoder.encode(String.valueOf(b.get("password"))));p.remove("password");db.insert("otps",Map.of("email",email,"type","doctor_register","code",otp,"payload",p));return Map.of("message","Verification code generated.","devOtp",otp);}
 @PostMapping("/api/doctor/auth/register/verify-otp") public ResponseEntity<?> doctorVerify(@RequestBody Map<String,Object>b){Map<String,Object>o=db.all("otps").stream().filter(x->String.valueOf(x.get("email")).equalsIgnoreCase(String.valueOf(b.get("email")))&&String.valueOf(x.get("type")).equals("doctor_register")&&String.valueOf(x.get("code")).equals(String.valueOf(b.get("code")))).findFirst().orElse(null);if(o==null)return ResponseEntity.badRequest().body(Map.of("message","Invalid verification code"));Map<String,Object>p=new HashMap<>((Map<String,Object>)o.get("payload"));Map<String,Object>d=db.insert("doctors",p);return ResponseEntity.ok(Map.of("doctor",publicUser(d),"token",jwt.create(db.toLong(d.get("id")),"doctor")));}
 @PostMapping("/api/doctor/auth/login") public ResponseEntity<?> doctorLogin(@RequestBody Map<String,Object>b){String docLoginEmail=String.valueOf(b.getOrDefault("email","")).trim().toLowerCase();validateEmail(docLoginEmail);Map<String,Object>d=db.findBy("doctors","email",docLoginEmail);if(d==null||!encoder.matches(String.valueOf(b.getOrDefault("password","")),String.valueOf(d.get("password_hash"))))return ResponseEntity.status(401).body(Map.of("message","Invalid credentials"));return ResponseEntity.ok(Map.of("doctor",publicUser(d),"token",jwt.create(db.toLong(d.get("id")),"doctor")));}

 @GetMapping("/api/doctor/me") public ResponseEntity<?> doctorMe(@RequestHeader(value="Authorization",required=false)String a){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(publicUser(db.find("doctors",id)));}
 @PutMapping("/api/doctor/me") public ResponseEntity<?> doctorUpdate(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){
  Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();
  Map<String,Object>x=normalizeHospitalAssignment(b);
  x=saveDoctorHospital(b,x);
  return ResponseEntity.ok(publicUser(db.update("doctors",id,x)));
 }
 @DeleteMapping("/api/doctor/me") public ResponseEntity<?> doctorDelete(@RequestHeader(value="Authorization",required=false)String a){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();db.remove("doctors",id);return ResponseEntity.ok(Map.of("deleted",true));}
 @PutMapping("/api/doctor/me/availability") public ResponseEntity<?> availability(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.update("doctors",id,Map.of("availability",b)));}

 // ---------- Doctor portal ----------
 @GetMapping("/api/doctor/hospitals") public ResponseEntity<?> doctorHospitals(@RequestHeader(value="Authorization",required=false)String a){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.all("hospitals"));}
 @PostMapping("/api/hospitals") public ResponseEntity<?> addHospital(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();Map<String,Object>x=new HashMap<>(b);x.put("created_by",id);return ResponseEntity.ok(db.insert("hospitals",x));}
 @PutMapping("/api/hospitals/{id}") public ResponseEntity<?> editHospital(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id,@RequestBody Map<String,Object>b){if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.update("hospitals",id,b));}
 @DeleteMapping("/api/hospitals/{id}") public ResponseEntity<?> deleteHospital(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){
  if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();
  Map<String,Object>unassign=new HashMap<>();unassign.put("hospital_id",null);
  for(Map<String,Object>d:db.filter("doctors","hospital_id",id)) db.update("doctors",db.toLong(d.get("id")),unassign);
  for(Map<String,Object>d:db.filter("doctors","hospitalId",id)) db.update("doctors",db.toLong(d.get("id")),unassign);
  return ResponseEntity.ok(Map.of("deleted",db.remove("hospitals",id)));
 }

 @GetMapping("/api/doctor/roster") public ResponseEntity<?> roster(@RequestHeader(value="Authorization",required=false)String a){if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.all("doctors").stream().map(this::publicUser).toList());}
 @PostMapping("/api/doctor/roster") public ResponseEntity<?> addDoctor(@RequestHeader(value="Authorization",required=false)String a,@RequestBody Map<String,Object>b){
  Long actor=userId(a,"doctor");if(actor==null)return ResponseEntity.status(401).build();
  Map<String,Object>x=normalizeHospitalAssignment(b);
  Map<String,Object> inserted=db.insert("doctors",x);
  inserted=saveDoctorHospital(b,inserted);
  return ResponseEntity.ok(publicUser(db.update("doctors",db.toLong(inserted.get("id")),inserted)));
 }
 @PutMapping("/api/doctor/roster/{id}") public ResponseEntity<?> editDoctor(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id,@RequestBody Map<String,Object>b){
  if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();
  Map<String,Object>x=normalizeHospitalAssignment(b);
  x=saveDoctorHospital(b,x);
  return ResponseEntity.ok(publicUser(db.update("doctors",id,x)));
 }
 @DeleteMapping("/api/doctor/roster/{id}") public ResponseEntity<?> deleteDoctor(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(Map.of("deleted",db.remove("doctors",id)));}

 @GetMapping("/api/doctor/appointments") public ResponseEntity<?> doctorAppointments(@RequestHeader(value="Authorization",required=false)String a,@RequestParam(required=false)String status,@RequestParam(required=false)String date){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("appointments","doctor_id",id).stream().filter(x->!"Completed".equals(String.valueOf(x.get("status")))).filter(x->status==null||status.isBlank()||String.valueOf(x.get("status")).equals(status)).filter(x->date==null||date.isBlank()||String.valueOf(x.get("appointment_date")).equals(date)).map(this::appointmentView).toList());}
 @GetMapping("/api/doctor/queue-prediction") public ResponseEntity<?> queue(@RequestHeader(value="Authorization",required=false)String a,@RequestParam String date){Long id=userId(a,"doctor");if(id==null)return ResponseEntity.status(401).build();return ResponseEntity.ok(db.filter("appointments","doctor_id",id).stream().filter(x->String.valueOf(x.get("appointment_date")).equals(date)).toList());}
 @GetMapping("/api/doctor/patients/{id}") public ResponseEntity<?> patient(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();Map<String,Object>p=db.find("patients",id);return p==null?ResponseEntity.notFound().build():ResponseEntity.ok(publicUser(p));}
 @GetMapping("/api/doctor/patients/{id}/monitoring") public ResponseEntity<?> monitoring(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){
  if(userId(a,"doctor")==null)return ResponseEntity.status(401).build();
  Map<String,Object> out=new LinkedHashMap<>();
  out.put("reports",db.filter("reports","patient_id",id));
  out.put("medications",db.filter("medications","patient_id",id));
  out.put("health_trends",buildHealthTrends(id));
  out.put("adherence",buildAdherence(id));
  return ResponseEntity.ok(out);
 }

 private ResponseEntity<?> statusChange(String a,long id,String status){
  Long doctorId=userId(a,"doctor");
  if(doctorId==null)return ResponseEntity.status(401).build();
  Map<String,Object> ap=db.find("appointments",id);
  if(ap==null)return ResponseEntity.notFound().build();
  if(!Objects.equals(String.valueOf(ap.get("doctor_id")),String.valueOf(doctorId)))return ResponseEntity.status(403).body(Map.of("message","You can only update your own appointments"));
  if("Completed".equals(status)){
   Map<String,Object> archive=new LinkedHashMap<>(ap);
   Map<String,Object> patient=db.find("patients",ap.get("patient_id"));
   Map<String,Object> doctor=db.find("doctors",ap.get("doctor_id"));
   Map<String,Object> hospital=db.find("hospitals",ap.get("hospital_id"));
   archive.put("completed_at",Instant.now().toString());
   archive.put("status","Completed");
   archive.put("patient",patient==null?Map.of():publicUser(patient));
   archive.put("doctor_name",doctor==null?"":doctor.get("name"));
   archive.put("specialty",doctor==null?"":doctor.get("specialty"));
   archive.put("hospital_name",hospital==null?"":hospital.get("name"));
   Map<String,Object> saved=db.insert("consulted_patients",archive);
   db.remove("appointments",id);
   return ResponseEntity.ok(Map.of("archived",true,"message","Consultation completed and moved to Consulted Patients folder","patient_id",ap.get("patient_id"),"consulted_patient",saved));
  }
  Map<String,Object>x=db.update("appointments",id,Map.of("status",status));
  return x==null?ResponseEntity.notFound().build():ResponseEntity.ok(appointmentView(x));
}
@GetMapping("/api/doctor/consulted-patients") public ResponseEntity<?> consultedPatients(@RequestHeader(value="Authorization",required=false)String a){
  Long doctorId=userId(a,"doctor");
  if(doctorId==null)return ResponseEntity.status(401).build();
  return ResponseEntity.ok(db.filter("consulted_patients","doctor_id",doctorId).stream()
    .sorted((x,y)->String.valueOf(y.getOrDefault("completed_at","")).compareTo(String.valueOf(x.getOrDefault("completed_at",""))))
    .map(x->{Map<String,Object> r=new LinkedHashMap<>(x); Object patient=x.get("patient"); if(patient instanceof Map<?,?> pm) r.put("patient",new LinkedHashMap<>((Map<String,Object>)pm)); return r;})
    .toList());
}
@GetMapping("/api/doctor/consulted-patients/{id}") public ResponseEntity<?> consultedPatient(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){
  Long doctorId=userId(a,"doctor");
  if(doctorId==null)return ResponseEntity.status(401).build();
  Map<String,Object> x=db.find("consulted_patients",id);
  if(x==null || !Objects.equals(String.valueOf(x.get("doctor_id")),String.valueOf(doctorId)))return ResponseEntity.notFound().build();
  return ResponseEntity.ok(x);
}

 @PutMapping("/api/doctor/appointments/{id}/accept") public ResponseEntity<?> accept(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){return statusChange(a,id,"Accepted");}
 @PutMapping("/api/doctor/appointments/{id}/complete") public ResponseEntity<?> complete(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){return statusChange(a,id,"Completed");}
 @PutMapping("/api/doctor/appointments/{id}/cancel") public ResponseEntity<?> cancel(@RequestHeader(value="Authorization",required=false)String a,@PathVariable long id){return statusChange(a,id,"Cancelled");}
}