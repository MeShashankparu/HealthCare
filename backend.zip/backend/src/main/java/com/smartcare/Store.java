package com.smartcare;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import jakarta.annotation.PostConstruct;
import java.nio.file.*;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

@Service
public class Store {
 private final ObjectMapper mapper=new ObjectMapper().findAndRegisterModules();
 private final Map<String,List<Map<String,Object>>> data=new HashMap<>();
 private final Path file;
 private final Object lock=new Object();

 public Store(@Value("${smartcare.data-file:${user.home}/.smartcare/db.json}") String path){file=Paths.get(path).toAbsolutePath().normalize();}

 @PostConstruct public void init(){
  synchronized(lock){
   System.out.println("[SmartCare] Using data file: "+file);
   try{
    Files.createDirectories(file.getParent()==null?Paths.get("."):file.getParent());
    if(Files.exists(file)) data.putAll(mapper.readValue(Files.readString(file),new TypeReference<Map<String,List<Map<String,Object>>>>(){}));
   }catch(Exception e){
    System.err.println("[SmartCare] WARNING: could not read existing data file ("+e.getMessage()+"). Starting from an empty in-memory store WITHOUT overwriting the file yet.");
    data.clear();
    for(String k: List.of("patients","hospitals","doctors","appointments","rewards","otps","prescriptions","medications","dose_logs","redemptions","reports","health_metrics","consulted_patients")) data.putIfAbsent(k,new ArrayList<>());
    return; // do not call save() here — avoid clobbering a file we failed to parse
   }
   for(String k: List.of("patients","hospitals","doctors","appointments","rewards","otps","prescriptions","medications","dose_logs","redemptions","reports","health_metrics","consulted_patients")) data.putIfAbsent(k,new ArrayList<>());
   migrateHospitalAssignments();
   migrateCompletedAppointments();
   save();
  }
 }

 private void migrateHospitalAssignments(){
  List<Map<String,Object>> doctors=data.get("doctors");
  if(doctors==null)return;
  for(Map<String,Object> doctor:doctors){
   Object legacy=doctor.get("hospitalId");
   Object assigned=doctor.get("hospital_id");
   if((assigned==null || String.valueOf(assigned).isBlank()) && legacy!=null && !String.valueOf(legacy).isBlank()){
    try{doctor.put("hospital_id",Long.parseLong(String.valueOf(legacy)));}catch(Exception ignored){}
   }
   doctor.remove("hospitalId");
  }
 }

 private void migrateCompletedAppointments(){
  List<Map<String,Object>> appointments=data.get("appointments");
  List<Map<String,Object>> archive=data.get("consulted_patients");
  if(appointments==null||archive==null)return;
  List<Map<String,Object>> completed=new ArrayList<>();
  for(Map<String,Object> ap: appointments){
   if("Completed".equals(String.valueOf(ap.get("status")))) completed.add(ap);
  }
  if(completed.isEmpty())return;
  for(Map<String,Object> ap: completed){
   boolean already=archive.stream().anyMatch(x->Objects.equals(String.valueOf(x.get("source_appointment_id")),String.valueOf(ap.get("id"))));
   if(already)continue;
   Map<String,Object> copy=new LinkedHashMap<>(ap);
   copy.remove("id");
   copy.put("source_appointment_id",ap.get("id"));
   copy.putIfAbsent("completed_at",ap.get("updated_at"));
   if(!copy.containsKey("completed_at")||copy.get("completed_at")==null)copy.put("completed_at",Instant.now().toString());
   long id=archive.stream().mapToLong(x->toLong(x.get("id"))).max().orElse(0)+1;
   copy.put("id",id);
   copy.putIfAbsent("created_at",Instant.now().toString());
   archive.add(copy);
  }
  appointments.removeIf(ap->"Completed".equals(String.valueOf(ap.get("status"))));
 }
 private void save(){try{Files.writeString(file,mapper.writerWithDefaultPrettyPrinter().writeValueAsString(data));}catch(Exception e){throw new RuntimeException(e);}}
 public List<Map<String,Object>> all(String c){synchronized(lock){return new ArrayList<>(data.getOrDefault(c,List.of()));}}
 public Map<String,Object> find(String c,Object id){return all(c).stream().filter(x->String.valueOf(x.get("id")).equals(String.valueOf(id))).findFirst().map(HashMap::new).orElse(null);}
 public Map<String,Object> findBy(String c,String key,Object value){return all(c).stream().filter(x->Objects.equals(String.valueOf(x.get(key)),String.valueOf(value))).findFirst().map(HashMap::new).orElse(null);}
 public List<Map<String,Object>> filter(String c,String key,Object value){return all(c).stream().filter(x->Objects.equals(String.valueOf(x.get(key)),String.valueOf(value))).toList();}
 public List<Map<String,Object>> filterWhere(String c, java.util.function.Predicate<Map<String,Object>> pred){return all(c).stream().filter(pred).toList();}
 public int removeWhere(String c, java.util.function.Predicate<Map<String,Object>> pred){synchronized(lock){int before=data.get(c).size();data.get(c).removeIf(pred);int removed=before-data.get(c).size();if(removed>0)save();return removed;}}
 public Map<String,Object> insert(String c,Map<String,Object> obj){synchronized(lock){long id=data.get(c).stream().mapToLong(x->toLong(x.get("id"))).max().orElse(0)+1;Map<String,Object> r=new LinkedHashMap<>();r.put("id",id);r.put("created_at",Instant.now().toString());r.putAll(obj);data.get(c).add(r);save();return new HashMap<>(r);}}
 public Map<String,Object> update(String c,Object id,Map<String,Object> changes){synchronized(lock){for(Map<String,Object> r:data.get(c)){if(String.valueOf(r.get("id")).equals(String.valueOf(id))){r.putAll(changes);save();return new HashMap<>(r);}}return null;}}
 public boolean remove(String c,Object id){synchronized(lock){boolean ok=data.get(c).removeIf(r->String.valueOf(r.get("id")).equals(String.valueOf(id)));if(ok)save();return ok;}}
 public long count(String c){return data.getOrDefault(c,List.of()).size();}
 public long toLong(Object o){try{return Long.parseLong(String.valueOf(o));}catch(Exception e){return 0;}}
 public Map<String,Object> parse(String json){try{return mapper.readValue(json,new TypeReference<Map<String,Object>>(){});}catch(Exception e){return new HashMap<>();}}
}